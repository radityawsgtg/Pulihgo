// App.tsx — PulihGo entry point
// Simple toggle between the gyro test and the MVP exercise screen.
// (Later: replace with a real navigator once flows grow.)

import { useState } from 'react';
import { SafeAreaView, View, Text, Pressable, StyleSheet, StatusBar } from 'react-native';
import GyroTestScreen from './src/screens/GyroTestScreen';
import ExerciseScreen from './src/screens/ExerciseScreen';
import SummaryScreen from './src/screens/SummaryScreen';

type Tab = 'exercise' | 'test' | 'summary';

export default function App() {
  const [tab, setTab] = useState<Tab>('exercise');

  return (
    <SafeAreaView style={styles.root}>
      <StatusBar barStyle="light-content" />
      <View style={styles.body}>
        {tab === 'exercise' && <ExerciseScreen />}
        {tab === 'test' && <GyroTestScreen />}
        {tab === 'summary' && <SummaryScreen />}
      </View>
      <View style={styles.tabs}>
        <TabBtn label="Exercise" active={tab === 'exercise'} onPress={() => setTab('exercise')} />
        <TabBtn label="Gyro test" active={tab === 'test'} onPress={() => setTab('test')} />
        <TabBtn label="Summary" active={tab === 'summary'} onPress={() => setTab('summary')} />
      </View>
    </SafeAreaView>
  );
}

function TabBtn({ label, active, onPress }: { label: string; active: boolean; onPress: () => void }) {
  return (
    <Pressable style={[styles.tab, active && styles.tabActive]} onPress={onPress}>
      <Text style={[styles.tabText, active && styles.tabTextActive]}>{label}</Text>
    </Pressable>
  );
}

const styles = StyleSheet.create({
  root: { flex: 1, backgroundColor: '#0d1b1e' },
  body: { flex: 1 },
  tabs: { flexDirection: 'row', borderTopWidth: 1, borderTopColor: '#12303a' },
  tab: { flex: 1, paddingVertical: 14, alignItems: 'center' },
  tabActive: { backgroundColor: '#12303a' },
  tabText: { color: '#6b8891', fontSize: 13 },
  tabTextActive: { color: '#12a5b8', fontWeight: 'bold' },
});
